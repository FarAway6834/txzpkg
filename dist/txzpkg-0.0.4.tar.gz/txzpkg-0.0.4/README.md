# txzpkg
download pkg as txz, install pkg as txz
